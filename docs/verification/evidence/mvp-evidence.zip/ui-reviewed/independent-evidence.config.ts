import {mergeConfig} from 'vitest/config';
import base from '../vite.config';
export default mergeConfig(base,{test:{include:['test-results/independent-evidence.test.tsx']}});
